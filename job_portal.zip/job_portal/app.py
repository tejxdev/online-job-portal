# app.py
from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import config

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
app.config.from_object(config)

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users(name, email, password) VALUES(%s, %s, %s)", (name, email, password))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email=%s AND password=%s", (email, password))
        user = cur.fetchone()
        cur.close()
        if user:
            session['user_id'] = user[0]
            session['user_name'] = user[1]
            return redirect(url_for('dashboard'))
        else:
            return "Invalid Credentials"
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()
    cur.close()
    return render_template('dashboard.html', jobs=jobs)

@app.route('/apply/<int:job_id>')
def apply(job_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO applications(user_id, job_id) VALUES(%s, %s)", (user_id, job_id))
    mysql.connection.commit()
    cur.close()
    return redirect(url_for('dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

# ----------- Admin Routes -----------
@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin123':
            session['admin'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            return "Invalid Admin Credentials"
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()
    cur.close()
    return render_template('admin_dashboard.html', jobs=jobs)

@app.route('/admin/add_job', methods=['GET', 'POST'])
def add_job():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        title = request.form['title']
        company = request.form['company']
        description = request.form['description']
        location = request.form['location']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO jobs(title, company, description, location) VALUES(%s, %s, %s, %s)",
                    (title, company, description, location))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('admin_dashboard'))
    return render_template('add_job.html')

if __name__ == "__main__":
    app.run(debug=True)
