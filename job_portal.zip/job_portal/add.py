@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin123':
            session['admin'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            return "Invalid Admin Credentials"
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM jobs")
    jobs = cur.fetchall()
    cur.close()
    return render_template('admin_dashboard.html', jobs=jobs)

@app.route('/admin/add_job', methods=['GET', 'POST'])
def add_job():
    if request.method == 'POST':
        title = request.form['title']
        company = request.form['company']
        description = request.form['description']
        location = request.form['location']

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO jobs(title, company, description, location) VALUES(%s, %s, %s, %s)",
                    (title, company, description, location))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('admin_dashboard'))
    return render_template('add_job.html')
