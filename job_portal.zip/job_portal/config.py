# config.py
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'programmer@123'
MYSQL_DB = 'jobportal'
SECRET_KEY = 'shubham@123'
